"""
SPIDER (System for Portfolio, Index, and Data Economic Relationships)
Configuration Module: Official Institutional Tickers, Concentric Topology,
Master Transmission Links, and Mathematical Thresholds.
"""

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from node_encyclopedia import NODE_ENCYCLOPEDIA, NodeManualEntry

# Base Directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
CACHE_DB_PATH = os.path.join(DATA_DIR, "spider_cache.db")
os.makedirs(DATA_DIR, exist_ok=True)

# Application Version
APP_VERSION = "V1.0"
APP_NAME = "SPIDER"
APP_FULL_NAME = f"SPIDER {APP_VERSION}"

# API Keys (Optional FRED key, default to institutional direct endpoints)
FRED_API_KEY = os.environ.get("FRED_API_KEY", "")

# Mathematical and Statistical Thresholds
Z_SCORE_NORMAL = 1.25
Z_SCORE_CRITICAL = 2.0

# Supported Time Windows for Rolling Correlations and Tension
TIME_WINDOWS = {
    "30D": {"days": 30, "label": "30 Giorni (Tattico Intraday/Breve)"},
    "90D": {"days": 90, "label": "90 Giorni (Trimestrale/Ciclico)"},
    "1Y": {"days": 365, "label": "1 Anno (Strutturale Intermedio)"},
    "5Y": {"days": 1825, "label": "5 Anni (Secolare Macroeconomico)"},
}
DEFAULT_TIME_WINDOW = "90D"

# Concentric Rings Definitions
RINGS = {
    1: {"name": "Anello 1 (Interno)", "label": "Politica Monetaria, Tassi & Rendimenti", "radius": 1.0},
    2: {"name": "Anello 2 (Intermedio)", "label": "Macroeconomia Reale (Fondamentali)", "radius": 2.0},
    3: {"name": "Anello 3 (Esterno)", "label": "Indici Azionari, Credito & Asset Intermarket", "radius": 3.0},
}

# Macro Quadrants
QUADRANTS = {
    "INFLATION": {"name": "Inflazione & Aspettative", "color": "#F59E0B", "angle_range": (30, 90)},
    "GROWTH": {"name": "Crescita & Produzione", "color": "#10B981", "angle_range": (90, 160)},
    "LABOR": {"name": "Lavoro & Occupazione", "color": "#3B82F6", "angle_range": (190, 260)},
    "LIQUIDITY_RISK": {"name": "Liquidità, Rischio & Tassi", "color": "#EC4899", "angle_range": (280, 350)},
}


@dataclass
class NodeDef:
    id: str
    name: str
    ring: int
    quadrant: str
    category: str
    official_ticker: str
    source: str
    frequency: str
    unit: str
    role: str
    angle_deg: float
    description: str
    transform: str = "level"  # "level", "yoy", "mom", "diff"


# 30 Peripheral Nodes Definition (8 in Ring 1, 10 in Ring 2, 12 in Ring 3)
NODES: Dict[str, NodeDef] = {
    # ------------------ ANELLO 1: POLITICA MONETARIA & RENDIMENTI ------------------
    "RATE_FED": NodeDef(
        id="RATE_FED",
        name="Fed Funds Effective Rate",
        ring=1,
        quadrant="LIQUIDITY_RISK",
        category="Tassi / Politica Monetaria",
        official_ticker="DFF",
        source="FRED / Federal Reserve",
        frequency="Giornaliera",
        unit="%",
        role="Tasso guida globale del costo del denaro USA",
        angle_deg=340,
        description="Tasso effettivo sui fondi federali overnight scambiati tra banche USA.",
        transform="level",
    ),
    "RATE_ECB": NodeDef(
        id="RATE_ECB",
        name="ECB Deposit Facility Rate",
        ring=1,
        quadrant="LIQUIDITY_RISK",
        category="Tassi / Politica Monetaria",
        official_ticker="ECBDFR",
        source="ECB / FRED",
        frequency="Giornaliera",
        unit="%",
        role="Tasso guida della politica monetaria Eurozona",
        angle_deg=305,
        description="Tasso di riferimento sui depositi presso la Banca Centrale Europea.",
        transform="level",
    ),
    "YIELD_US02": NodeDef(
        id="YIELD_US02",
        name="US Treasury 2Y Yield",
        ring=1,
        quadrant="LIQUIDITY_RISK",
        category="Tassi / Yields",
        official_ticker="DGS2",
        source="FRED / US Treasury",
        frequency="Giornaliera",
        unit="%",
        role="Termometro puro delle mosse future della FED a 12-24 mesi",
        angle_deg=330,
        description="Rendimento del titolo governativo USA a 2 anni, anticipatore pivot tassi.",
        transform="level",
    ),
    "YIELD_US10": NodeDef(
        id="YIELD_US10",
        name="US Treasury 10Y Yield",
        ring=1,
        quadrant="LIQUIDITY_RISK",
        category="Tassi / Yields",
        official_ticker="DGS10",
        source="FRED / US Treasury / CME",
        frequency="Giornaliera",
        unit="%",
        role="Benchmark globale per il tasso di sconto di tutti gli asset finanziari",
        angle_deg=280,
        description="Rendimento del decennale USA; ancora fondamentale per mutui e DCF azionari.",
        transform="level",
    ),
    "YIELD_REAL10": NodeDef(
        id="YIELD_REAL10",
        name="US 10Y TIPS (Real Yield)",
        ring=1,
        quadrant="INFLATION",
        category="Tassi / Yields Reali",
        official_ticker="DFII10",
        source="FRED / US Treasury",
        frequency="Giornaliera",
        unit="%",
        role="Rendimento reale al netto dell'inflazione; barometro per Tech e Oro",
        angle_deg=45,
        description="Rendimento reale del decennale protetto dall'inflazione TIPS.",
        transform="level",
    ),
    "CURVE_10_2": NodeDef(
        id="CURVE_10_2",
        name="Spread Curva USA 10Y-2Y",
        ring=1,
        quadrant="GROWTH",
        category="Tassi / Pendenza Curva",
        official_ticker="T10Y2Y",
        source="FRED",
        frequency="Giornaliera",
        unit="bps",
        role="Indicatore primario di inversione della curva e ciclo recessivo",
        angle_deg=145,
        description="Differenziale di rendimento tra scadenza a 10 anni e a 2 anni USA.",
        transform="level",
    ),
    "YIELD_DE10": NodeDef(
        id="YIELD_DE10",
        name="Bund Tedesco 10Y",
        ring=1,
        quadrant="LIQUIDITY_RISK",
        category="Tassi / Yields Sovrani UE",
        official_ticker="IRLTLT01DEM156N",
        source="FRED / Bundesbank / ECB",
        frequency="Giornaliera/Mensile",
        unit="%",
        role="Benchmark privo di rischio per l'intera area Euro",
        angle_deg=255,
        description="Rendimento del Bund governativo decennale tedesco.",
        transform="level",
    ),
    "SPREAD_BTP": NodeDef(
        id="SPREAD_BTP",
        name="Spread BTP 10Y - Bund 10Y",
        ring=1,
        quadrant="LIQUIDITY_RISK",
        category="Rischio Sovrano UE",
        official_ticker="SPREAD_IT_DE",
        source="ECB Data Portal / TradingView / FRED",
        frequency="Giornaliera",
        unit="bps",
        role="Termometro del rischio sovrano e frammentazione dell'Eurozona",
        angle_deg=230,
        description="Differenziale di rendimento tra BTP italiano 10Y e Bund tedesco 10Y.",
        transform="level",
    ),

    # ------------------ ANELLO 2: MACROECONOMIA REALE ------------------
    "INF_USCPI": NodeDef(
        id="INF_USCPI",
        name="US CPI All Urban (YoY)",
        ring=2,
        quadrant="INFLATION",
        category="Macro / Inflazione",
        official_ticker="CPIAUCSL",
        source="FRED / BLS",
        frequency="Mensile",
        unit="%",
        role="Indice prezzi al consumo primario USA (Headline)",
        angle_deg=35,
        description="Tasso annuo di variazione dell'indice CPI per consumatori urbani USA.",
        transform="level",
    ),
    "INF_USPCE": NodeDef(
        id="INF_USPCE",
        name="US Core PCE Price Index",
        ring=2,
        quadrant="INFLATION",
        category="Macro / Inflazione",
        official_ticker="PCEPILFE",
        source="FRED / BEA",
        frequency="Mensile",
        unit="%",
        role="Misura d'inflazione core prediletta dalla Federal Reserve",
        angle_deg=55,
        description="Indice prezzi spese per consumi personali core (esclusi cibo ed energia).",
        transform="level",
    ),
    "INF_EXP5Y": NodeDef(
        id="INF_EXP5Y",
        name="5Y5Y Forward Inflation Exp.",
        ring=2,
        quadrant="INFLATION",
        category="Macro / Inflazione",
        official_ticker="T5YIFR",
        source="FRED / Federal Reserve",
        frequency="Giornaliera",
        unit="%",
        role="Aspettative d'inflazione forward a medio-lungo termine a 5 anni",
        angle_deg=70,
        description="Tasso d'inflazione forward a 5 anni atteso nei 5 anni successivi.",
        transform="level",
    ),
    "INF_EZHICP": NodeDef(
        id="INF_EZHICP",
        name="Eurozone HICP Inflation",
        ring=2,
        quadrant="INFLATION",
        category="Macro / Inflazione",
        official_ticker="CP0000EZ19M086NEST",
        source="Eurostat / ECB / FRED",
        frequency="Mensile",
        unit="%",
        role="Indice armonizzato dei prezzi al consumo dell'area Euro",
        angle_deg=85,
        description="Variazione tendenziale annua dell'indice armonizzato HICP Eurozona.",
        transform="level",
    ),
    "LAB_UNRATE": NodeDef(
        id="LAB_UNRATE",
        name="US Unemployment Rate (U3)",
        ring=2,
        quadrant="LABOR",
        category="Macro / Lavoro",
        official_ticker="UNRATE",
        source="FRED / BLS",
        frequency="Mensile",
        unit="%",
        role="Tasso di disoccupazione ufficiale USA U3",
        angle_deg=195,
        description="Percentuale della forza lavoro disoccupata e attivamente in cerca d'impiego.",
        transform="level",
    ),
    "LAB_NFP": NodeDef(
        id="LAB_NFP",
        name="Non-Farm Payrolls (Level)",
        ring=2,
        quadrant="LABOR",
        category="Macro / Lavoro",
        official_ticker="PAYEMS",
        source="FRED / BLS",
        frequency="Mensile",
        unit="k dipendenti",
        role="Numero totale di lavoratori dipendenti extra-agricoli USA",
        angle_deg=215,
        description="Totale buste paga nel settore non-agricolo; driver occupazionale chiave.",
        transform="mom",
    ),
    "LAB_CLAIMS": NodeDef(
        id="LAB_CLAIMS",
        name="Initial Jobless Claims",
        ring=2,
        quadrant="LABOR",
        category="Macro / Lavoro",
        official_ticker="ICSA",
        source="FRED / Dept. of Labor",
        frequency="Settimanale",
        unit="Richieste",
        role="Richieste settimanali di nuovi sussidi di disoccupazione",
        angle_deg=240,
        description="Indicatore tempestivo ad alta frequenza di licenziamenti e stress occupazionale.",
        transform="level",
    ),
    "GRO_USGDP": NodeDef(
        id="GRO_USGDP",
        name="US Real GDP (QoQ Ann.)",
        ring=2,
        quadrant="GROWTH",
        category="Macro / Crescita",
        official_ticker="A191RL1Q225SBEA",
        source="FRED / BEA",
        frequency="Trimestrale",
        unit="%",
        role="Tasso di crescita annualizzato del PIL reale USA",
        angle_deg=110,
        description="Variazione percentuale trimestrale annualizzata del Prodotto Interno Lordo reale.",
        transform="level",
    ),
    "GRO_INDPRO": NodeDef(
        id="GRO_INDPRO",
        name="US Industrial Production (YoY)",
        ring=2,
        quadrant="GROWTH",
        category="Macro / Crescita",
        official_ticker="INDPRO",
        source="FRED / Federal Reserve",
        frequency="Mensile",
        unit="%",
        role="Tasso di crescita annuo dell'output manifatturiero, minerario ed elettrico",
        angle_deg=130,
        description="Variazione percentuale tendenziale annua della produzione industriale reale.",
        transform="level",
    ),
    "GRO_RETAIL": NodeDef(
        id="GRO_RETAIL",
        name="US Retail Sales (YoY)",
        ring=2,
        quadrant="GROWTH",
        category="Macro / Crescita",
        official_ticker="RSXFS",
        source="FRED / Census Bureau",
        frequency="Mensile",
        unit="%",
        role="Tasso di crescita annuo delle vendite al dettaglio (termometro consumi)",
        angle_deg=155,
        description="Variazione percentuale tendenziale annua delle vendite al dettaglio USA escluso il settore auto.",
        transform="level",
    ),

    # ------------------ ANELLO 3: INDICI, ASSET & COMMODITIES ------------------
    "EQ_SPX": NodeDef(
        id="EQ_SPX",
        name="S&P 500",
        ring=3,
        quadrant="GROWTH",
        category="Equity USA",
        official_ticker="^GSPC",
        source="S&P Dow Jones / CME / Yahoo",
        frequency="Real-Time / Daily",
        unit="pt",
        role="Benchmark azionario globale a larga capitalizzazione",
        angle_deg=115,
        description="Indice azionario ponderato sulle 500 maggiori società quotate USA.",
        transform="level",
    ),
    "EQ_NDX": NodeDef(
        id="EQ_NDX",
        name="Nasdaq 100",
        ring=3,
        quadrant="GROWTH",
        category="Equity USA",
        official_ticker="^NDX",
        source="Nasdaq / CME / Yahoo",
        frequency="Real-Time / Daily",
        unit="pt",
        role="Asset a lunga duration tecnologica, ultra-sensibile ai rendimenti reali",
        angle_deg=95,
        description="Indice delle 100 maggiori società non finanziarie ad alta intensità tech.",
        transform="level",
    ),
    "EQ_RUT": NodeDef(
        id="EQ_RUT",
        name="Russell 2000",
        ring=3,
        quadrant="GROWTH",
        category="Equity USA",
        official_ticker="^RUT",
        source="FTSE Russell / Yahoo",
        frequency="Real-Time / Daily",
        unit="pt",
        role="Small-cap domestiche; sensibile al costo del debito bancario e ciclo interno",
        angle_deg=135,
        description="Indice delle 2000 società a minore capitalizzazione del mercato USA.",
        transform="level",
    ),
    "EQ_DAX": NodeDef(
        id="EQ_DAX",
        name="DAX 40",
        ring=3,
        quadrant="GROWTH",
        category="Equity UE",
        official_ticker="^GDAXI",
        source="Deutsche Börse / Yahoo",
        frequency="Real-Time / Daily",
        unit="pt",
        role="Ciclico industriale europeo ad alta esposizione all'export globale",
        angle_deg=145,
        description="Indice dei 40 titoli a maggiore capitalizzazione della borsa di Francoforte.",
        transform="level",
    ),
    "EQ_MIB": NodeDef(
        id="EQ_MIB",
        name="FTSE MIB",
        ring=3,
        quadrant="LIQUIDITY_RISK",
        category="Equity UE",
        official_ticker="FTSEMIB.MI",
        source="Borsa Italiana / Euronext / Yahoo",
        frequency="Real-Time / Daily",
        unit="pt",
        role="Indice ad alto peso bancario; sensibile a tassi BCE e Spread BTP",
        angle_deg=215,
        description="Indice principale di Piazza Affari con forte concentrazione creditizia.",
        transform="level",
    ),
    "RISK_VIX": NodeDef(
        id="RISK_VIX",
        name="CBOE Volatility Index",
        ring=3,
        quadrant="LIQUIDITY_RISK",
        category="Rischio / Volatilità",
        official_ticker="^VIX",
        source="CBOE / Yahoo",
        frequency="Real-Time / Daily",
        unit="pt",
        role="Prezzo delle coperture opzionali istituzionali sull'S&P 500 (Indice della Paura)",
        angle_deg=265,
        description="Volatilità implicita a 30 giorni delle opzioni su S&P 500.",
        transform="level",
    ),
    "CRED_HY": NodeDef(
        id="CRED_HY",
        name="ICE BofA US High Yield Spread",
        ring=3,
        quadrant="LIQUIDITY_RISK",
        category="Credito / Rischio",
        official_ticker="BAMLH0A0HYM2",
        source="ICE Data Indices / FRED",
        frequency="Giornaliera",
        unit="%",
        role="Misura lo stress sul debito societario speculativo; predittivo per small-cap",
        angle_deg=285,
        description="Spread OAS dei titoli obbligazionari societari High Yield rispetto ai Treasury.",
        transform="level",
    ),
    "FX_DXY": NodeDef(
        id="FX_DXY",
        name="US Dollar Index",
        ring=3,
        quadrant="LIQUIDITY_RISK",
        category="Valute",
        official_ticker="DX-Y.NYB",
        source="ICE / Yahoo",
        frequency="Real-Time / Daily",
        unit="pt",
        role="Condizioni finanziarie globali; drena o inietta liquidità dollaro nel mondo",
        angle_deg=315,
        description="Paniere del dollaro USA ponderato rispetto a 6 valute primarie (EUR, JPY, GBP...).",
        transform="level",
    ),
    "FX_EURUSD": NodeDef(
        id="FX_EURUSD",
        name="Cambio EUR/USD",
        ring=3,
        quadrant="LIQUIDITY_RISK",
        category="Valute",
        official_ticker="EURUSD=X",
        source="ECB / Forex Market / Yahoo",
        frequency="Real-Time / Daily",
        unit="USD/EUR",
        role="Riflette il differenziale monetario tra FED/Treasury e BCE/Bund",
        angle_deg=335,
        description="Tasso di cambio spot principale del commercio mondiale.",
        transform="level",
    ),
    "COM_GOLD": NodeDef(
        id="COM_GOLD",
        name="Oro (Gold Futures)",
        ring=3,
        quadrant="INFLATION",
        category="Commodities / Metalli Preziosi",
        official_ticker="GC=F",
        source="COMEX / CME / Yahoo",
        frequency="Real-Time / Daily",
        unit="$/oz",
        role="Copertura su rendimenti reali negativi, de-dollarizzazione e rischio fiat",
        angle_deg=40,
        description="Contratto future di riferimento sull'oncia troy d'oro.",
        transform="level",
    ),
    "COM_OIL": NodeDef(
        id="COM_OIL",
        name="Petrolio WTI",
        ring=3,
        quadrant="INFLATION",
        category="Commodities / Energia",
        official_ticker="CL=F",
        source="NYMEX / CME / Yahoo",
        frequency="Real-Time / Daily",
        unit="$/bbl",
        role="Input primario dell'inflazione headline e tassa implicita sui consumi",
        angle_deg=65,
        description="Prezzo del barile di greggio West Texas Intermediate.",
        transform="level",
    ),
    "COM_COPPER": NodeDef(
        id="COM_COPPER",
        name="Rame (Copper Futures)",
        ring=3,
        quadrant="GROWTH",
        category="Commodities / Metalli Industriali",
        official_ticker="HG=F",
        source="COMEX / CME / Yahoo",
        frequency="Real-Time / Daily",
        unit="$/lb",
        role="'Dr. Copper': anticipatore puro della produzione e dell'attività industriale globale",
        angle_deg=120,
        description="Metallo industriale primario con dottorato in economia per la sua capacità predittiva.",
        transform="level",
    ),
}


@dataclass
class MasterLinkDef:
    id: str
    node_a: str
    node_b: str
    theoretical_corr: int  # +1 or -1
    mechanism: str
    alert_description: str
    weight: float = 1.0


# The 10 Master Transmission Links encoded into the Quantitative Engine
MASTER_LINKS: Dict[str, MasterLinkDef] = {
    "LINK_01": MasterLinkDef(
        id="LINK_01",
        node_a="INF_USPCE",
        node_b="YIELD_US02",
        theoretical_corr=+1,
        mechanism="L'inflazione core spinge il mercato a prezzare rialzi (o mancati tagli) della FED sul titolo a 2 anni.",
        alert_description="Se l'inflazione sale ma il 2Y scende, il mercato prezza uno shock recessivo imminente o pivot forzato.",
        weight=1.2,
    ),
    "LINK_02": MasterLinkDef(
        id="LINK_02",
        node_a="YIELD_REAL10",
        node_b="EQ_NDX",
        theoretical_corr=-1,
        mechanism="Rendimenti reali più alti comprimono il multiplo P/E e riducono il valore attuale dei flussi futuri Big Tech.",
        alert_description="Se salgono entrambi, l'azionario è in fase di espansione euforica dei multipli a rischio di violento repricing.",
        weight=1.5,
    ),
    "LINK_03": MasterLinkDef(
        id="LINK_03",
        node_a="YIELD_REAL10",
        node_b="COM_GOLD",
        theoretical_corr=-1,
        mechanism="L'oro non paga cedole: soffre la concorrenza quando i Treasury offrono un rendimento reale positivo elevato.",
        alert_description="Se salgono entrambi, c'è accumulazione istituzionale per rischio sovrano, debito insostenibile o de-dollarizzazione.",
        weight=1.3,
    ),
    "LINK_04": MasterLinkDef(
        id="LINK_04",
        node_a="COM_OIL",
        node_b="INF_EXP5Y",
        theoretical_corr=+1,
        mechanism="Il prezzo dell'energia trasmette impulsi diretti e aspettative di inflazione alle scadenze a medio termine.",
        alert_description="Se il petrolio crolla ma le aspettative d'inflazione restano elevate, l'inflazione è diventata strutturale nei salari e servizi.",
        weight=1.1,
    ),
    "LINK_05": MasterLinkDef(
        id="LINK_05",
        node_a="LAB_CLAIMS",
        node_b="CURVE_10_2",
        theoretical_corr=+1,
        mechanism="L'aumento dei sussidi disoccupazione forza il bull-steepening (il rendimento a 2Y crolla più velocemente del 10Y per tagli FED).",
        alert_description="Se i sussidi salgono e la curva si inverte ulteriormente, la FED è percepita 'behind the curve' e in ritardo.",
        weight=1.2,
    ),
    "LINK_06": MasterLinkDef(
        id="LINK_06",
        node_a="CRED_HY",
        node_b="EQ_RUT",
        theoretical_corr=-1,
        mechanism="L'allargamento degli spread High Yield restringe il credito e soffoca per prime le small-cap del Russell 2000.",
        alert_description="Se gli spread di credito salgono mentre gli indici azionari fanno nuovi massimi, il rally equity è fragile e privo di supporto creditizio.",
        weight=1.4,
    ),
    "LINK_07": MasterLinkDef(
        id="LINK_07",
        node_a="YIELD_US02",
        node_b="FX_EURUSD",
        theoretical_corr=-1,
        mechanism="Quando i rendimenti a breve USA salgono più di quelli europei, i capitali fluiscono sul Dollaro deprimendo EUR/USD.",
        alert_description="Divergenza tra differenziale tassi e cambio segnala flussi anomali di rimpatrio o stress di liquidità off-shore in USD.",
        weight=1.1,
    ),
    "LINK_08": MasterLinkDef(
        id="LINK_08",
        node_a="FX_DXY",
        node_b="EQ_SPX",
        theoretical_corr=-1,
        mechanism="Un dollaro troppo forte restringe le condizioni finanziarie globali e deprime gli utili esteri delle multinazionali S&P 500.",
        alert_description="Dollaro e S&P 500 entrambi in forte rialzo indicano che gli asset USA stanno agendo da unico rifugio di liquidità mondiale.",
        weight=1.3,
    ),
    "LINK_09": MasterLinkDef(
        id="LINK_09",
        node_a="COM_COPPER",
        node_b="GRO_INDPRO",
        theoretical_corr=+1,
        mechanism="Il rame anticipa tempestivamente l'espansione o la contrazione del ciclo manifatturiero e delle forniture industriali.",
        alert_description="Rame in crollo con produzione industriale ancora forte segnala un imminente rallentamento ciclico non ancora recepito nei dati ufficiali.",
        weight=1.1,
    ),
    "LINK_10": MasterLinkDef(
        id="LINK_10",
        node_a="SPREAD_BTP",
        node_b="EQ_MIB",
        theoretical_corr=-1,
        mechanism="L'allargamento dello spread sovrano svaluta il portafoglio titoli di stato e alza il costo di funding per le banche che dominano il FTSE MIB.",
        alert_description="Se lo spread sale ma il FTSE MIB ignora il movimento, si accumula un rischio asimmetrico represso sul settore bancario.",
        weight=1.3,
    ),
}

# Secondary Radial Spokes linking SPIDER_CORE to Ring 1, and Ring 1 to Ring 2 & Ring 3
SECONDARY_SPOKES = [
    # Core to Ring 1 (Anchor Spokes)
    ("SPIDER_CORE", "RATE_FED", +1, "Liquidità & Tassi Guida Globali"),
    ("SPIDER_CORE", "RATE_ECB", +1, "Politica Monetaria Eurozona"),
    ("SPIDER_CORE", "YIELD_US10", +1, "Benchmark Globale Costo del Capitale"),
    ("SPIDER_CORE", "CURVE_10_2", +1, "Pendenza Curva & Anticipazione Ciclica"),
    ("SPIDER_CORE", "YIELD_REAL10", +1, "Rendimento Reale Risk-Free"),
    # Ring 1 to Ring 2 (Monetary Transmission to Real Economy)
    ("RATE_FED", "INF_USPCE", +1, "FED Target Inflation Gap"),
    ("RATE_FED", "LAB_UNRATE", -1, "Curva di Phillips & Dual Mandate"),
    ("RATE_ECB", "INF_EZHICP", +1, "BCE Inflation Mandate"),
    ("YIELD_US10", "GRO_USGDP", +1, "Tasso Neutrale di Crescita Potenziale"),
    ("CURVE_10_2", "GRO_INDPRO", +1, "Pendenza Curva e Produzione"),
    # Ring 2 to Ring 3 (Fundamentals to Financial Markets)
    ("GRO_USGDP", "EQ_SPX", +1, "Crescita Economica e Utili Azionari"),
    ("GRO_RETAIL", "EQ_RUT", +1, "Consumi Privati e Piccole Imprese"),
    ("LAB_UNRATE", "RISK_VIX", +1, "Disoccupazione e Volatilità Sistemica"),
    ("INF_USCPI", "COM_OIL", +1, "Componente Energetica Inflazione"),
    ("YIELD_DE10", "EQ_DAX", -1, "Tassi Tedeschi e Valutazioni Industriali"),
    ("RATE_ECB", "SPREAD_BTP", +1, "Restrizione BCE e Pressione Periferici"),
]
